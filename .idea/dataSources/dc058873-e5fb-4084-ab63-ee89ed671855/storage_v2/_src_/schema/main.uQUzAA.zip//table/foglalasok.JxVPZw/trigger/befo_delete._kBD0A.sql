CREATE TRIGGER befo_delete BEFORE DELETE ON foglalasok
BEGIN
 SELECT CASE 
   WHEN (SELECT COUNT(id) FROM
 foglalasok 
   WHERE
    vetites_id = old.vetites_id
    and date(datum) <= (SELECT date('now','start of month','-1 day'))) > 0
  THEN RAISE(ABORT,  'Nem lehet több mint 24 óra')
END; 
END;

